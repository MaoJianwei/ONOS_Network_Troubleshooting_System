from mininet.topo import Topo

class linear2( Topo ):

	def __init__(self):

		Topo.__init__(self)

		host1 = self.addHost('h1')
		host2 = self.addHost('h2')

		switch1 = self.addSwitch('s1')
		switch2 = self.addSwitch('s2')

		self.addLink(switch1, host1, 1, 0)
		self.addLink(switch2, host2, 1, 0)
		self.addLink(switch1, switch2, 2, 2)

topos = {'linear2': ( lambda: linear2() )}