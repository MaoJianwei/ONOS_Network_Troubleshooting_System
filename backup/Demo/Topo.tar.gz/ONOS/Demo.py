import re
from mininet.cli import CLI
from mininet.log import setLogLevel, info,error
from mininet.net import Mininet
from mininet.link import Intf
from mininet.topolib import TreeTopo
from mininet.util import quietRun
from mininet.node import RemoteController, OVSKernelSwitch
from mininet.topo import Topo


class Demo(Topo):
    
    def __init__(self):
        Topo.__init__(self)


        # sA = self.addSwitch('sA',dpid="0000000000000001")
        # sB = self.addSwitch('sB',dpid="0000000000000002")
        # sC = self.addSwitch('sC',dpid="0000000000000003")
        # sD = self.addSwitch('sD',dpid="0000000000000004")
        # sE = self.addSwitch('sE',dpid="0000000000000005")
        # sF = self.addSwitch('sF',dpid="0000000000000006")
        # sG = self.addSwitch('sG',dpid="0000000000000007") 

        sA = self.addSwitch('sA',dpid="0001111111111111")
        sB = self.addSwitch('sB',dpid="0002222222222222")
        sC = self.addSwitch('sC',dpid="0003333333333333")
        sD = self.addSwitch('sD',dpid="0004444444444444")
        sE = self.addSwitch('sE',dpid="0005555555555555")
        sF = self.addSwitch('sF',dpid="0006666666666666")
        sG = self.addSwitch('sG',dpid="0007777777777777") 

        # sA = self.addSwitch('sA',dpid="1111111111111111")
        # sB = self.addSwitch('sB',dpid="2222222222222222")
        # sC = self.addSwitch('sC',dpid="3333333333333333")
        # sD = self.addSwitch('sD',dpid="4444444444444444")
        # sE = self.addSwitch('sE',dpid="5555555555555555")
        # sF = self.addSwitch('sF',dpid="6666666666666666")
        # sG = self.addSwitch('sG',dpid="7777777777777777")
        
        A = self.addHost('A',ip="10.0.0.1")
        B = self.addHost('B',ip="10.0.0.2")
        C = self.addHost('C',ip="10.0.0.3")
        D = self.addHost('D',ip="10.0.0.4")
        E = self.addHost('E',ip="10.0.0.5")
        F = self.addHost('F',ip="10.0.0.6")
        G = self.addHost('G',ip="10.0.0.7")

        self.addLink(node1=sA,port1=1,node2=sB,port2=1)
        self.addLink(node1=sC,port1=1,node2=sD,port2=1)
        self.addLink(node1=sA,port1=2,node2=sD,port2=2)
        self.addLink(node1=sB,port1=2,node2=sC,port2=2)
        self.addLink(node1=sC,port1=3,node2=sE,port2=3)
        self.addLink(node1=sE,port1=1,node2=sF,port2=1)
        self.addLink(node1=sE,port1=2,node2=sG,port2=2)

        
        self.addLink(node1=sA,port1=3,node2=A,port2=0)
        self.addLink(node1=sB,port1=3,node2=B,port2=0)
        self.addLink(node1=sD,port1=3,node2=C,port2=0)
        self.addLink(node1=sF,port1=2,node2=D,port2=0)
        self.addLink(node1=sF,port1=3,node2=E,port2=0)   
        self.addLink(node1=sG,port1=1,node2=F,port2=0)   
        self.addLink(node1=sG,port1=3,node2=G,port2=0)         
        
topos = { 'Demo' : ( lambda : Demo() ) }
