from mininet.topo import Topo

class loop3( Topo ):

	def __init__(self):

		Topo.__init__(self)

		host1 = self.addHost('h1',ip="10.0.0.1")
		host2 = self.addHost('h2',ip="10.0.0.2")
		host3 = self.addHost('h3',ip="10.0.0.3")

		switch1 = self.addSwitch('s1',dpid="0001111111111111")
		switch2 = self.addSwitch('s2',dpid="0002222222222222")
		switch3 = self.addSwitch('s3',dpid="0003333333333333")

		self.addLink(switch1, host1, 1, 0)
		self.addLink(switch2, host2, 1, 0)
		self.addLink(switch3, host3, 1, 0)
		self.addLink(switch1, switch2, 2, 2)
		self.addLink(switch1, switch3, 3, 2)
		self.addLink(switch2, switch3, 3, 3)

topos = {'loop3': ( lambda: loop3() )}