/*
 * Copyright 2014 Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.FNL;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferenceCardinality;
import org.apache.felix.scr.annotations.Service;
import org.onlab.packet.Ethernet;
import org.onlab.packet.IPv4;
import org.onlab.packet.IpPrefix;
import org.onlab.packet.TCP;
import org.onlab.packet.TpPort;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.DeviceId;
import org.onosproject.net.PortNumber;
import org.onosproject.net.flow.DefaultFlowRule;
import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.FlowRule;
import org.onosproject.net.flow.FlowRuleService;
import org.onosproject.net.flow.TrafficSelector;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.packet.PacketContext;
import org.onosproject.net.packet.PacketPriority;
import org.onosproject.net.packet.PacketProcessor;
import org.onosproject.net.packet.PacketService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Skeletal ONOS application component.
 */
@Component(immediate = true)
public class DemoSSH {

    private final Logger log = LoggerFactory.getLogger(getClass());

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected FlowRuleService flowRuleService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected CoreService coreService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected PacketService packetService;

    private PacketProcessor packetProcessor = new InternalPacketProcessor();
    private ApplicationId appId;

    private Map<String,Long> dpid_icmp_turn;
    private Map<String,Long> dpid_icmp_ipDst_port;
//    private Map<String,Map<String,Long>> dpid_udp_ipDst_out_port;

    private short servicePort = 22;

    private List<String> hasPushDevice = new ArrayList<>();

    @Activate
    protected void activate() {

        initMap_dpid_icmp_turn();
        initMap_dpid_icmp_ipDst_port();
//        initMap_dpid_udp_ipDst_out_port();


        appId = coreService.registerApplication("org.onosproject.FNL.Demo-SSH");

        packetService.addProcessor(packetProcessor, PacketProcessor.director(0));
        requestIntercepts();

        log.info("Started");
    }

    @Deactivate
    protected void deactivate() {
        packetService.removeProcessor(packetProcessor);
        log.info("Stopped");
    }

    private void requestIntercepts() {
        TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
        selectorBuilder.matchEthType(Ethernet.TYPE_IPV4);
        selectorBuilder.matchIPProtocol(IPv4.PROTOCOL_TCP);
        packetService.requestPackets(selectorBuilder.build(), PacketPriority.REACTIVE, appId);
    }

    private void initMap_dpid_icmp_turn(){
        dpid_icmp_turn = new HashMap<>();
        dpid_icmp_turn.put("0001111111111111",2L);
        dpid_icmp_turn.put("0002222222222222",1L);
        dpid_icmp_turn.put("0003333333333333",2L);
        dpid_icmp_turn.put("0004444444444444",1L);
    }

    private void initMap_dpid_icmp_ipDst_port(){
        dpid_icmp_ipDst_port = new HashMap<>();
        dpid_icmp_ipDst_port.put("10.0.0.1",3L);
        dpid_icmp_ipDst_port.put("10.0.0.2",3L);
        dpid_icmp_ipDst_port.put("10.0.0.3",3L);
        dpid_icmp_ipDst_port.put("10.0.0.4",2L);
        dpid_icmp_ipDst_port.put("10.0.0.5",3L);
        dpid_icmp_ipDst_port.put("10.0.0.6",1L);
        dpid_icmp_ipDst_port.put("10.0.0.7",3L);
    }

//    private void initMap_dpid_udp_ipDst_out_port(){
//
//        dpid_udp_ipDst_out_port = new HashMap<>();
//        dpid_udp_ipDst_out_port.put("0001111111111111", new HashMap<String, Long>());
//        dpid_udp_ipDst_out_port.put("0002222222222222", new HashMap<String, Long>());
//        dpid_udp_ipDst_out_port.put("0003333333333333", new HashMap<String, Long>());
//        dpid_udp_ipDst_out_port.put("0004444444444444", new HashMap<String, Long>());
//        dpid_udp_ipDst_out_port.put("0005555555555555", new HashMap<String, Long>());
//        dpid_udp_ipDst_out_port.put("0006666666666666", new HashMap<String, Long>());
//        dpid_udp_ipDst_out_port.put("0007777777777777", new HashMap<String, Long>());
//
//        Map<String, Long> tempForward = null;
//
//        tempForward = dpid_udp_ipDst_out_port.get("0001111111111111");
//        tempForward.put("10.0.0.1", 3L);
//        tempForward.put("10.0.0.2", 1L);
//        tempForward.put("10.0.0.3", 2L);
//        tempForward.put("10.0.0.4", 1L);
//        tempForward.put("10.0.0.5", 1L);
//        tempForward.put("10.0.0.6", 2L);
//        tempForward.put("10.0.0.7", 2L);
//
//        tempForward = dpid_udp_ipDst_out_port.get("0002222222222222");
//        tempForward.put("10.0.0.1", 1L);
//        tempForward.put("10.0.0.2", 3L);
//        tempForward.put("10.0.0.3", 2L);
//        tempForward.put("10.0.0.4", 2L);
//        tempForward.put("10.0.0.5", 2L);
//        tempForward.put("10.0.0.6", 2L);
//        tempForward.put("10.0.0.7", 2L);
//
//        tempForward = dpid_udp_ipDst_out_port.get("0003333333333333");
//        tempForward.put("10.0.0.1", 2L);
//        tempForward.put("10.0.0.2", 2L);
//        tempForward.put("10.0.0.3", 1L);
//        tempForward.put("10.0.0.4", 3L);
//        tempForward.put("10.0.0.5", 3L);
//        tempForward.put("10.0.0.6", 3L);
//        tempForward.put("10.0.0.7", 3L);
//
//        tempForward = dpid_udp_ipDst_out_port.get("0004444444444444");
//        tempForward.put("10.0.0.1", 2L);
//        tempForward.put("10.0.0.2", 1L);
//        tempForward.put("10.0.0.3", 3L);
//        tempForward.put("10.0.0.4", 1L);
//        tempForward.put("10.0.0.5", 1L);
//        tempForward.put("10.0.0.6", 1L);
//        tempForward.put("10.0.0.7", 1L);
//
//        tempForward = dpid_udp_ipDst_out_port.get("0005555555555555");
//        tempForward.put("10.0.0.1", 3L);
//        tempForward.put("10.0.0.2", 3L);
//        tempForward.put("10.0.0.3", 3L);
//        tempForward.put("10.0.0.4", 1L);
//        tempForward.put("10.0.0.5", 1L);
//        tempForward.put("10.0.0.6", 2L);
//        tempForward.put("10.0.0.7", 2L);
//
//        tempForward = dpid_udp_ipDst_out_port.get("0006666666666666");
//        tempForward.put("10.0.0.1", 1L);
//        tempForward.put("10.0.0.2", 1L);
//        tempForward.put("10.0.0.3", 1L);
//        tempForward.put("10.0.0.4", 2L);
//        tempForward.put("10.0.0.5", 3L);
//        tempForward.put("10.0.0.6", 1L);
//        tempForward.put("10.0.0.7", 1L);
//
//        tempForward = dpid_udp_ipDst_out_port.get("0007777777777777");
//        tempForward.put("10.0.0.1", 2L);
//        tempForward.put("10.0.0.2", 2L);
//        tempForward.put("10.0.0.3", 2L);
//        tempForward.put("10.0.0.4", 2L);
//        tempForward.put("10.0.0.5", 2L);
//        tempForward.put("10.0.0.6", 1L);
//        tempForward.put("10.0.0.7", 3L);
//    }

    private class InternalPacketProcessor implements PacketProcessor{
        @Override
        public void process(PacketContext context){

            if(context.isHandled())
                return;

            Ethernet ethPkt = context.inPacket().parsed();

            if(ethPkt.getEtherType()!=Ethernet.TYPE_IPV4)
                return;

            IPv4 ipPkt = (IPv4)ethPkt.getPayload();

            if(ipPkt.getProtocol() != IPv4.PROTOCOL_TCP)
                return;

            TCP tcpPkt = (TCP) ipPkt.getPayload();

            if(servicePort != tcpPkt.getDestinationPort() && servicePort != tcpPkt.getSourcePort())
                return;

            DeviceId deviceId = context.inPacket().receivedFrom().deviceId();
            String deviceIdStr = deviceId.uri().getSchemeSpecificPart();

            if(hasPushDevice.contains(deviceIdStr))
                return;

            // Push all flow belong to this Device

            if(deviceIdStr.equals("0001111111111111")){
                hasPushDevice.add("0001111111111111");
                pushFlowToLoopDevice(deviceId,deviceIdStr);

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.1/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.1")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.1/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.1")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

            }else if(deviceIdStr.equals("0002222222222222")){
                hasPushDevice.add("0002222222222222");
                pushFlowToLoopDevice(deviceId,deviceIdStr);

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.2/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.2")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.2/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.2")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

            }else if(deviceIdStr.equals("0003333333333333")){
                hasPushDevice.add("0003333333333333");
                pushFlowToLoopDevice(deviceId,deviceIdStr);

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.4/30"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(3));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }


                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.4/30"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(3));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }


            }else if(deviceIdStr.equals("0004444444444444")){
                hasPushDevice.add("0004444444444444");
                pushFlowToLoopDevice(deviceId,deviceIdStr);

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.3/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.3")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.3/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.3")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

            }else if(deviceIdStr.equals("0005555555555555")){
                hasPushDevice.add("0005555555555555");
                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.0/30"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(3));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.4/31"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(1));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.6/31"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(2));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.0/30"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(3));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.4/31"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(1));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.6/31"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(2));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

            }else if(deviceIdStr.equals("0006666666666666")){
                hasPushDevice.add("0006666666666666");
                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.6/31"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(1));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.0/30"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(1));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.6/31"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(1));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.0/30"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(1));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.4/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.4")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.5/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.5")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

            }else if(deviceIdStr.equals("0007777777777777")){
                hasPushDevice.add("0007777777777777");
                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.4/31"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(2));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.0/30"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpDst(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(2));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.4/31"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(2));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.0/30"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(2));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(33333)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.6/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.6")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }

                {
                    TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                    selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPDst(IpPrefix.valueOf("10.0.0.7/32"))
                            .matchIPProtocol(IPv4.PROTOCOL_TCP)
                            .matchTcpSrc(TpPort.tpPort(servicePort));

                    TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                    trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_ipDst_port.get("10.0.0.7")));

                    FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
                    flowRuleBuilder.forDevice(deviceId)
                            .fromApp(appId)
                            .withSelector(selectorBuilder.build())
                            .withTreatment(trafficTreatmentBuilder.build())
                            .withPriority(55555)
                            .withCookie(appId.id())
                            .makePermanent();

                    flowRuleService.applyFlowRules(flowRuleBuilder.build());
                }
            }

            packetOutputTable(context);

        }

        private void pushFlowToLoopDevice(DeviceId deviceId, String deviceIdStr){
            TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                    .matchIPDst(IpPrefix.valueOf("10.0.0.0/8"))
                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                    .matchTcpDst(TpPort.tpPort(servicePort));

            TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_turn.get(deviceIdStr)));

            FlowRule.Builder flowRuleBuilder = DefaultFlowRule.builder();
            flowRuleBuilder.forDevice(deviceId)
                    .fromApp(appId)
                    .withSelector(selectorBuilder.build())
                    .withTreatment(trafficTreatmentBuilder.build())
                    .withPriority(33333)
                    .withCookie(appId.id())
                    .makePermanent();

            flowRuleService.applyFlowRules(flowRuleBuilder.build());



            selectorBuilder = DefaultTrafficSelector.builder();
            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                    .matchIPDst(IpPrefix.valueOf("10.0.0.0/8"))
                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                    .matchTcpSrc(TpPort.tpPort(servicePort));

            trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_icmp_turn.get(deviceIdStr)));

            flowRuleBuilder = DefaultFlowRule.builder();
            flowRuleBuilder.forDevice(deviceId)
                    .fromApp(appId)
                    .withSelector(selectorBuilder.build())
                    .withTreatment(trafficTreatmentBuilder.build())
                    .withPriority(33333)
                    .withCookie(appId.id())
                    .makePermanent();

            flowRuleService.applyFlowRules(flowRuleBuilder.build());

        }

        private void packetOutputTable(PacketContext context) {
            context.treatmentBuilder().setOutput(PortNumber.TABLE);
            context.send();
        }
    }
}
