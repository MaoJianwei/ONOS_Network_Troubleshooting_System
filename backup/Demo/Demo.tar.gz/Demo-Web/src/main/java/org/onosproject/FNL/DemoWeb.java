/*
 * Copyright 2014 Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.FNL;


import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferenceCardinality;
import org.apache.felix.scr.annotations.Service;
import org.onlab.packet.EthType;
import org.onlab.packet.Ethernet;
import org.onlab.packet.IPv4;
import org.onlab.packet.IpPrefix;
import org.onlab.packet.TCP;
import org.onlab.packet.TpPort;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.DeviceId;
import org.onosproject.net.PortNumber;
import org.onosproject.net.flow.DefaultFlowRule;
import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.FlowRule;
import org.onosproject.net.flow.FlowRuleService;
import org.onosproject.net.flow.TrafficSelector;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.packet.PacketContext;
import org.onosproject.net.packet.PacketPriority;
import org.onosproject.net.packet.PacketProcessor;
import org.onosproject.net.packet.PacketService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;

/**
 * Host C
 */
@Component(immediate = true)
public class DemoWeb {

    private final Logger log = LoggerFactory.getLogger(getClass());

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected CoreService coreService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected PacketService packetService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected FlowRuleService flowRuleService;

    protected ApplicationId appId;
    protected PacketProcessor packetProcessor = new InternalPacketProcessor();

    private HashMap<String, HashMap<String, Long>> dpid_forward_ipSrc_port;
    private HashMap<String, HashMap<String, Long>> dpid_backward_ipDst_port;

    private int servicePort = 80;

    @Activate
    protected void activate() {
        log.info("init...");

        initForwardMap();
        initBackwardMap();

        appId = coreService.registerApplication("org.onosproject.FNL.Demo-Web");


        packetService.addProcessor(packetProcessor, PacketProcessor.director(0));//TODO - check priority
        requestIntercept();

        log.info("Started");
    }

    @Deactivate
    protected void deactivate() {

        packetService.removeProcessor(packetProcessor);

        log.info("Stopped");
    }

    private void requestIntercept() {
        TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
        selectorBuilder.matchEthType(Ethernet.TYPE_IPV4);
        selectorBuilder.matchIPProtocol(IPv4.PROTOCOL_TCP);
        packetService.requestPackets(selectorBuilder.build(), PacketPriority.REACTIVE, appId);
    }

    private void initForwardMap() {
        dpid_forward_ipSrc_port = new HashMap<String, HashMap<String, Long>>();
        dpid_forward_ipSrc_port.put("0001111111111111", new HashMap<String, Long>());
        dpid_forward_ipSrc_port.put("0002222222222222", new HashMap<String, Long>());
        dpid_forward_ipSrc_port.put("0003333333333333", new HashMap<String, Long>());
        dpid_forward_ipSrc_port.put("0004444444444444", new HashMap<String, Long>());
        dpid_forward_ipSrc_port.put("0005555555555555", new HashMap<String, Long>());
        dpid_forward_ipSrc_port.put("0006666666666666", new HashMap<String, Long>());
        dpid_forward_ipSrc_port.put("0007777777777777", new HashMap<String, Long>());

        HashMap<String, Long> tempForward = null;

        tempForward = dpid_forward_ipSrc_port.get("0001111111111111");
        tempForward.put("10.0.0.1", 2L);
        tempForward.put("10.0.0.2", 2L);
        tempForward.put("10.0.0.3", -1L);
        tempForward.put("10.0.0.4", -1L);
        tempForward.put("10.0.0.5", -1L);
        tempForward.put("10.0.0.6", -1L);
        tempForward.put("10.0.0.7", -1L);

        tempForward = dpid_forward_ipSrc_port.get("0002222222222222");
        tempForward.put("10.0.0.1", 2L);
        tempForward.put("10.0.0.2", 1L);
        tempForward.put("10.0.0.3", -1L);
        tempForward.put("10.0.0.4", -1L);
        tempForward.put("10.0.0.5", -1L);
        tempForward.put("10.0.0.6", -1L);
        tempForward.put("10.0.0.7", -1L);

        tempForward = dpid_forward_ipSrc_port.get("0003333333333333");
        tempForward.put("10.0.0.1", 1L);
        tempForward.put("10.0.0.2", 1L);
        tempForward.put("10.0.0.3", 2L);
        tempForward.put("10.0.0.4", 1L);
        tempForward.put("10.0.0.5", 1L);
        tempForward.put("10.0.0.6", 1L);
        tempForward.put("10.0.0.7", 1L);

        tempForward = dpid_forward_ipSrc_port.get("0004444444444444");
        tempForward.put("10.0.0.1", 3L);
        tempForward.put("10.0.0.2", 3L);
        tempForward.put("10.0.0.3", 3L);
        tempForward.put("10.0.0.4", 3L);
        tempForward.put("10.0.0.5", 3L);
        tempForward.put("10.0.0.6", 3L);
        tempForward.put("10.0.0.7", 3L);

        tempForward = dpid_forward_ipSrc_port.get("0005555555555555");
        tempForward.put("10.0.0.1", 3L);
        tempForward.put("10.0.0.2", 3L);
        tempForward.put("10.0.0.3", 3L);
        tempForward.put("10.0.0.4", 3L);
        tempForward.put("10.0.0.5", 3L);
        tempForward.put("10.0.0.6", 3L);
        tempForward.put("10.0.0.7", 3L);

        tempForward = dpid_forward_ipSrc_port.get("0006666666666666");
        tempForward.put("10.0.0.1", 1L);
        tempForward.put("10.0.0.2", 1L);
        tempForward.put("10.0.0.3", 1L);
        tempForward.put("10.0.0.4", 1L);
        tempForward.put("10.0.0.5", 1L);
        tempForward.put("10.0.0.6", 1L);
        tempForward.put("10.0.0.7", 1L);

        tempForward = dpid_forward_ipSrc_port.get("0007777777777777");
        tempForward.put("10.0.0.1", 2L);
        tempForward.put("10.0.0.2", 2L);
        tempForward.put("10.0.0.3", 2L);
        tempForward.put("10.0.0.4", 2L);
        tempForward.put("10.0.0.5", 2L);
        tempForward.put("10.0.0.6", 2L);
        tempForward.put("10.0.0.7", 2L);
    }

    private void initBackwardMap() {
        dpid_backward_ipDst_port = new HashMap<String, HashMap<String, Long>>();
        dpid_backward_ipDst_port.put("0001111111111111", new HashMap<String, Long>());
        dpid_backward_ipDst_port.put("0002222222222222", new HashMap<String, Long>());
        dpid_backward_ipDst_port.put("0003333333333333", new HashMap<String, Long>());
        dpid_backward_ipDst_port.put("0004444444444444", new HashMap<String, Long>());
        dpid_backward_ipDst_port.put("0005555555555555", new HashMap<String, Long>());
        dpid_backward_ipDst_port.put("0006666666666666", new HashMap<String, Long>());
        dpid_backward_ipDst_port.put("0007777777777777", new HashMap<String, Long>());

        HashMap<String, Long> tempForward = null;

        tempForward = dpid_backward_ipDst_port.get("0001111111111111");
        tempForward.put("10.0.0.1", 3L);
        tempForward.put("10.0.0.2", 1L);
        tempForward.put("10.0.0.3", 2L);
        tempForward.put("10.0.0.4", 1L);
        tempForward.put("10.0.0.5", 1L);
        tempForward.put("10.0.0.6", 1L);
        tempForward.put("10.0.0.7", 1L);

        tempForward = dpid_backward_ipDst_port.get("0002222222222222");
        tempForward.put("10.0.0.1", 1L);
        tempForward.put("10.0.0.2", 3L);
        tempForward.put("10.0.0.3", 1L);
        tempForward.put("10.0.0.4", 1L);
        tempForward.put("10.0.0.5", 1L);
        tempForward.put("10.0.0.6", 1L);
        tempForward.put("10.0.0.7", 1L);

        tempForward = dpid_backward_ipDst_port.get("0003333333333333");
        tempForward.put("10.0.0.1", 2L);
        tempForward.put("10.0.0.2", 2L);
        tempForward.put("10.0.0.3", 1L);
        tempForward.put("10.0.0.4", 3L);
        tempForward.put("10.0.0.5", 3L);
        tempForward.put("10.0.0.6", 3L);
        tempForward.put("10.0.0.7", 3L);

        tempForward = dpid_backward_ipDst_port.get("0004444444444444");
        tempForward.put("10.0.0.1", 2L);
        tempForward.put("10.0.0.2", 2L);
        tempForward.put("10.0.0.3", 3L);
        tempForward.put("10.0.0.4", 1L);
        tempForward.put("10.0.0.5", 1L);
        tempForward.put("10.0.0.6", 1L);
        tempForward.put("10.0.0.7", 1L);

        tempForward = dpid_backward_ipDst_port.get("0005555555555555");
        tempForward.put("10.0.0.1", 3L);
        tempForward.put("10.0.0.2", 3L);
        tempForward.put("10.0.0.3", 3L);
        tempForward.put("10.0.0.4", 1L);
        tempForward.put("10.0.0.5", 1L);
        tempForward.put("10.0.0.6", 2L);
        tempForward.put("10.0.0.7", 2L);

        tempForward = dpid_backward_ipDst_port.get("0006666666666666");
        tempForward.put("10.0.0.1", 1L);
        tempForward.put("10.0.0.2", 1L);
        tempForward.put("10.0.0.3", 1L);
        tempForward.put("10.0.0.4", 2L);
        tempForward.put("10.0.0.5", 3L);
        tempForward.put("10.0.0.6", 1L);
        tempForward.put("10.0.0.7", 1L);

        tempForward = dpid_backward_ipDst_port.get("0007777777777777");
        tempForward.put("10.0.0.1", 2L);
        tempForward.put("10.0.0.2", 2L);
        tempForward.put("10.0.0.3", 2L);
        tempForward.put("10.0.0.4", 2L);
        tempForward.put("10.0.0.5", 2L);
        tempForward.put("10.0.0.6", 1L);
        tempForward.put("10.0.0.7", 3L);
    }

    private class InternalPacketProcessor implements PacketProcessor {
        @Override
        public void process(PacketContext context) {

            if (context.isHandled()) {
                return;
            }

            Ethernet ethPkt = context.inPacket().parsed();

            if (ethPkt == null) {
                return;
            }

            if (ethPkt.getEtherType() == Ethernet.TYPE_IPV4) {

                IPv4 ipPkt = (IPv4) ethPkt.getPayload();
                if (ipPkt.getProtocol() == IPv4.PROTOCOL_TCP) {

                    TCP tcpPkt = (TCP) ipPkt.getPayload();

                    String ipSrc = IPv4.fromIPv4Address(ipPkt.getSourceAddress());
                    String ipDst = IPv4.fromIPv4Address(ipPkt.getDestinationAddress());
                    int portSrc = tcpPkt.getSourcePort();
                    int portDst = tcpPkt.getDestinationPort();

                    DeviceId deviceId = context.inPacket().receivedFrom().deviceId();
                    String deviceStr = deviceId.uri().getSchemeSpecificPart();

                    if (!dpid_forward_ipSrc_port.get(deviceStr).containsKey(ipDst)) {
                        return;
                    }

                    if (servicePort == portDst) {

                        if (deviceStr.equals("0005555555555555") ||
                                deviceStr.equals("0006666666666666") ||
                                deviceStr.equals("0007777777777777")) {

                            TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                                    .matchTcpDst(TpPort.tpPort(portDst));

                            TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_forward_ipSrc_port.get(deviceStr).get(ipSrc)));

                            TrafficSelector selector = selectorBuilder.build();
                            TrafficTreatment treatment = trafficTreatmentBuilder.build();

                            FlowRule.Builder ruleBuilder = DefaultFlowRule.builder();
                            ruleBuilder.fromApp(appId)
                                    .forDevice(deviceId)
                                    .makePermanent()
                                    .withPriority(33333)
                                    .withSelector(selector)
                                    .withTreatment(treatment)
                                    .withCookie(appId.id());
                            FlowRule rule = ruleBuilder.build();

                            flowRuleService.applyFlowRules(rule);

                            // no need for backward

                        } else if (deviceStr.equals("0003333333333333")) {

                            TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                                    .matchIPSrc(IpPrefix.valueOf(ipSrc + "/32"))
                                    .matchIPDst(IpPrefix.valueOf(ipDst + "/32"))
                                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                                    .matchTcpDst(TpPort.tpPort(portDst));

                            TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_forward_ipSrc_port.get(deviceStr).get(ipSrc)));

                            TrafficSelector selector = selectorBuilder.build();
                            TrafficTreatment treatment = trafficTreatmentBuilder.build();

                            FlowRule.Builder ruleBuilder = DefaultFlowRule.builder();
                            ruleBuilder.fromApp(appId)
                                    .forDevice(deviceId)
                                    .makePermanent()
                                    .withPriority(33333)
                                    .withSelector(selector)
                                    .withTreatment(treatment)
                                    .withCookie(appId.id());
                            FlowRule rule = ruleBuilder.build();

                            flowRuleService.applyFlowRules(rule);

                            //backward

                            selectorBuilder = DefaultTrafficSelector.builder();
                            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                                    .matchIPSrc(IpPrefix.valueOf(ipDst + "/32"))
                                    .matchIPDst(IpPrefix.valueOf(ipSrc + "/32"))
                                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                                    .matchTcpSrc(TpPort.tpPort(portDst));

                            trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_backward_ipDst_port.get(deviceStr).get(ipSrc)));

                            selector = selectorBuilder.build();
                            treatment = trafficTreatmentBuilder.build();

                            ruleBuilder = DefaultFlowRule.builder();
                            ruleBuilder.fromApp(appId)
                                    .forDevice(deviceId)
                                    .makePermanent()
                                    .withPriority(33333)
                                    .withSelector(selector)
                                    .withTreatment(treatment)
                                    .withCookie(appId.id());
                            rule = ruleBuilder.build();

                            flowRuleService.applyFlowRules(rule);

                        } else if (deviceStr.equals("0004444444444444")) {

                            TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                                    .matchTcpDst(TpPort.tpPort(portDst));

                            TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_forward_ipSrc_port.get(deviceStr).get(ipSrc)));

                            TrafficSelector selector = selectorBuilder.build();
                            TrafficTreatment treatment = trafficTreatmentBuilder.build();

                            FlowRule.Builder ruleBuilder = DefaultFlowRule.builder();
                            ruleBuilder.fromApp(appId)
                                    .forDevice(deviceId)
                                    .makePermanent()
                                    .withPriority(33333)
                                    .withSelector(selector)
                                    .withTreatment(treatment)
                                    .withCookie(appId.id() + 0);
                            FlowRule rule = ruleBuilder.build();

                            flowRuleService.applyFlowRules(rule);

                        } else if (deviceStr.equals("0002222222222222")) {

                            TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                                    .matchIPSrc(IpPrefix.valueOf(ipSrc + "/32"))
                                    .matchIPDst(IpPrefix.valueOf(ipDst + "/32"))
                                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                                    .matchTcpDst(TpPort.tpPort(portDst));

                            TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_forward_ipSrc_port.get(deviceStr).get(ipSrc)));

                            TrafficSelector selector = selectorBuilder.build();
                            TrafficTreatment treatment = trafficTreatmentBuilder.build();

                            FlowRule.Builder ruleBuilder = DefaultFlowRule.builder();
                            ruleBuilder.fromApp(appId)
                                    .forDevice(deviceId)
                                    .makePermanent()
                                    .withPriority(33333)
                                    .withSelector(selector)
                                    .withTreatment(treatment)
                                    .withCookie(appId.id());
                            FlowRule rule = ruleBuilder.build();

                            flowRuleService.applyFlowRules(rule);

                            //backward

                            selectorBuilder = DefaultTrafficSelector.builder();
                            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                                    .matchIPSrc(IpPrefix.valueOf(ipDst + "/32"))
                                    .matchIPDst(IpPrefix.valueOf(ipSrc + "/32"))
                                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                                    .matchTcpSrc(TpPort.tpPort(portDst));

                            trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_backward_ipDst_port.get(deviceStr).get(ipSrc)));

                            selector = selectorBuilder.build();
                            treatment = trafficTreatmentBuilder.build();

                            ruleBuilder = DefaultFlowRule.builder();
                            ruleBuilder.fromApp(appId)
                                    .forDevice(deviceId)
                                    .makePermanent()
                                    .withPriority(33333)
                                    .withSelector(selector)
                                    .withTreatment(treatment)
                                    .withCookie(appId.id() + 0);
                            rule = ruleBuilder.build();

                            flowRuleService.applyFlowRules(rule);

                        } else if (deviceStr.equals("0001111111111111")) {

                            TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                                    .matchIPSrc(IpPrefix.valueOf(ipSrc + "/32"))
                                    .matchIPDst(IpPrefix.valueOf(ipDst + "/32"))
                                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                                    .matchTcpDst(TpPort.tpPort(portDst));

                            TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_forward_ipSrc_port.get(deviceStr).get(ipSrc)));

                            TrafficSelector selector = selectorBuilder.build();
                            TrafficTreatment treatment = trafficTreatmentBuilder.build();

                            FlowRule.Builder ruleBuilder = DefaultFlowRule.builder();
                            ruleBuilder.fromApp(appId)
                                    .forDevice(deviceId)
                                    .makePermanent()
                                    .withPriority(33333)
                                    .withSelector(selector)
                                    .withTreatment(treatment)
                                    .withCookie(appId.id() + 0);
                            FlowRule rule = ruleBuilder.build();

                            flowRuleService.applyFlowRules(rule);

                            //backward

                            selectorBuilder = DefaultTrafficSelector.builder();
                            selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                                    .matchIPSrc(IpPrefix.valueOf(ipDst + "/32"))
                                    .matchIPDst(IpPrefix.valueOf(ipSrc + "/32"))
                                    .matchIPProtocol(IPv4.PROTOCOL_TCP)
                                    .matchTcpSrc(TpPort.tpPort(portDst));

                            trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                            trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_backward_ipDst_port.get(deviceStr).get(ipSrc)));

                            selector = selectorBuilder.build();
                            treatment = trafficTreatmentBuilder.build();

                            ruleBuilder = DefaultFlowRule.builder();
                            ruleBuilder.fromApp(appId)
                                    .forDevice(deviceId)
                                    .makePermanent()
                                    .withPriority(33333)
                                    .withSelector(selector)
                                    .withTreatment(treatment)
                                    .withCookie(appId.id());
                            rule = ruleBuilder.build();

                            flowRuleService.applyFlowRules(rule);

                        }

                    } else if (servicePort == portSrc ||
                            deviceStr.equals("0004444444444444") ||
                            deviceStr.equals("0005555555555555") ||
                            deviceStr.equals("0006666666666666") ||
                            deviceStr.equals("0007777777777777")) {

                        //backward
                        TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
                        selectorBuilder.matchEthType(Ethernet.TYPE_IPV4)
                                .matchIPSrc(IpPrefix.valueOf(ipSrc + "/32"))
                                .matchIPDst(IpPrefix.valueOf(ipDst + "/32"))
                                .matchIPProtocol(IPv4.PROTOCOL_TCP)
                                .matchTcpSrc(TpPort.tpPort(portSrc));

                        TrafficTreatment.Builder trafficTreatmentBuilder = DefaultTrafficTreatment.builder();
                        trafficTreatmentBuilder.setOutput(PortNumber.portNumber(dpid_backward_ipDst_port.get(deviceStr).get(ipDst)));

                        TrafficSelector selector = selectorBuilder.build();
                        TrafficTreatment treatment = trafficTreatmentBuilder.build();

                        FlowRule.Builder ruleBuilder = DefaultFlowRule.builder();
                        ruleBuilder.fromApp(appId)
                                .forDevice(deviceId)
                                .makePermanent()
                                .withPriority(33333)
                                .withSelector(selector)
                                .withTreatment(treatment)
                                .withCookie(appId.id());
                        FlowRule rule = ruleBuilder.build();

                        flowRuleService.applyFlowRules(rule);

                    }

                    packetOutputTable(context);

                }
            }
        }

        private void packetOutputTable(PacketContext context) {
            context.treatmentBuilder().setOutput(PortNumber.TABLE);
            context.send();
        }
    }

}







