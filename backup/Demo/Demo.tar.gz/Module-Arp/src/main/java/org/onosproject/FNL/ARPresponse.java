/*
 * Copyright 2014 Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.FNL;


import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Modified;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferenceCardinality;
import org.onlab.packet.ARP;
import org.onlab.packet.Ethernet;
import org.onlab.packet.Ip4Address;
import org.onlab.packet.MacAddress;
import org.onlab.util.Tools;
import org.onosproject.cfg.ComponentConfigService;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.ConnectPoint;
import org.onosproject.net.edge.EdgePortService;
import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.FlowRuleService;
import org.onosproject.net.flow.TrafficSelector;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.host.HostService;
import org.onosproject.net.packet.DefaultOutboundPacket;
import org.onosproject.net.packet.InboundPacket;
import org.onosproject.net.packet.PacketContext;
import org.onosproject.net.packet.PacketPriority;
import org.onosproject.net.packet.PacketProcessor;
import org.onosproject.net.packet.PacketService;
import org.onosproject.net.topology.TopologyService;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static com.google.common.base.Strings.isNullOrEmpty;


/**
 * Skeletal ONOS application component.
 */
@Component(immediate = true)
public class ARPresponse {

    private final Logger log = LoggerFactory.getLogger(getClass());

    private Map<String, String> ipToMac = null;

    private ArpPacketProxy arpPacketProxy = null;

    private ApplicationId appId = null;


    private static final boolean testBoolean = false;
    private static final int testInt = 7182;
    private static final String beijing = "beiJing";

    @Property(name = "maoBoolean", boolValue = testBoolean, label = "maoBoolLabel", description = "Mao Bool Desc")
    private boolean maoBoolean = testBoolean;

    @Property(name = "maoInt", intValue = testInt, label = "maoIntLabel", description = "Mao Int Desc")
    private int maoInt = testInt;

    @Property(name = "maoString", value = beijing, label = "maoStringLabel", description = "Mao String Description")
    private String maoString = beijing;


    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected CoreService coreService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected PacketService packetService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected EdgePortService edgePortService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected ComponentConfigService componentConfigService;


    @Activate
    protected void activate(ComponentContext context) {
        log.info("Init...");

        ipToMac = new HashMap<String, String>();
        ipToMac.put("10.0.0.1", "00:00:00:00:00:01");
        ipToMac.put("10.0.0.2", "00:00:00:00:00:02");
        ipToMac.put("10.0.0.3", "00:00:00:00:00:03");
        ipToMac.put("10.0.0.4", "00:00:00:00:00:04");
        ipToMac.put("10.0.0.5", "00:00:00:00:00:05");
        ipToMac.put("10.0.0.6", "00:00:00:00:00:06");
        ipToMac.put("10.0.0.7", "00:00:00:00:00:07");


        appId = coreService.registerApplication("org.onosproject.FNL.Module-Arp");

        arpPacketProxy = new ArpPacketProxy();
        packetService.addProcessor(arpPacketProxy, PacketProcessor.director(0));// TODO - check - deal first

        requestIntercept();

        componentConfigService.registerProperties(getClass());
        readComponentConfiguration(context);

        log.info("Started");
    }

    @Deactivate
    protected void deactivate(ComponentContext context) {
        log.info("Release...");

        ipToMac = null;

        withdrawIntercept();
        packetService.removeProcessor(arpPacketProxy);
        arpPacketProxy = null;

        appId = null;

        componentConfigService.unregisterProperties(getClass(), false);

        log.info("Stopped");
    }

    @Modified
    protected void modified(ComponentContext context) {
        readComponentConfiguration(context);
    }

    private boolean readComponentConfiguration(ComponentContext context) {
        if (context == null) {
            return false;
        }

        Set<String> s = componentConfigService.getComponentNames();

        Dictionary<?, ?> properties = context.getProperties();

//        //TODO - Tools.get()
//        String temp;
//        temp = (String) properties.get("maoBoolean");
//        maoBoolean = isNullOrEmpty(temp) ? testBoolean :temp.trim().equals("true");
//
//        temp = (String) properties.get("maoInt");
//        maoInt = isNullOrEmpty(temp)?testInt:Integer.parseInt(temp);
//
//        temp = (String) properties.get("maoString");
//        maoString = isNullOrEmpty(temp)?beijing:temp;

        int aa = 1;
        return true;
    }

    private void requestIntercept() {
        TrafficSelector.Builder selector = DefaultTrafficSelector.builder();
        selector.matchEthType(Ethernet.TYPE_ARP);
        packetService.requestPackets(selector.build(), PacketPriority.REACTIVE, appId);
        selector.matchEthType(Ethernet.TYPE_IPV6);
        int a = 1;
    }

    private void withdrawIntercept() {
        TrafficSelector.Builder selector = DefaultTrafficSelector.builder();
        selector.matchEthType(Ethernet.TYPE_ARP);
        packetService.cancelPackets(selector.build(), PacketPriority.REACTIVE, appId);
        int a = 1;
    }


    private class ArpPacketProxy implements PacketProcessor {
        /**
         * TODO - mark - packetOut example
         *
         * @param context packet processing context
         */
        @Override
        public void process(PacketContext context) {

            if (context.isHandled()) {
                return;
            }

            InboundPacket pkt = context.inPacket();
            Ethernet ethPkt = pkt.parsed();
            ConnectPoint rcvFrom = pkt.receivedFrom();

            if (Ethernet.TYPE_ARP != ethPkt.getEtherType()) {
                return;
            }

            if (!edgePortService.isEdgePoint(rcvFrom)) {
                return;
            }

            Ip4Address srcIpReply = Ip4Address.valueOf(((ARP) ethPkt.getPayload()).getTargetProtocolAddress());
            String mac = ipToMac.get(srcIpReply.toString());

            if (null == mac) {
                return;
            }

            MacAddress srcMacReply = MacAddress.valueOf(mac);

            Ethernet arpReply = ARP.buildArpReply(srcIpReply, srcMacReply, ethPkt);

            TrafficTreatment.Builder builder = DefaultTrafficTreatment.builder();
            builder.setOutput(rcvFrom.port());
            packetService.emit(new DefaultOutboundPacket(rcvFrom.deviceId(), builder.build(), ByteBuffer.wrap(arpReply.serialize())));

            context.block();

            int a = 1;
        }

        // Indicates whether this is a control packet, e.g. LLDP, BDDP
        private boolean isControlPacket(Ethernet eth) {
            short type = eth.getEtherType();
            return type == Ethernet.TYPE_LLDP || type == Ethernet.TYPE_BSN;
        }
    }


}
